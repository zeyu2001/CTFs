export default function () {
    return 9000 + Math.floor(Math.random() * 2000);
}