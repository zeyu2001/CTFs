export default function () {
    console.log.apply(null, ['[+]', ...arguments]);
}