export default function (_, res) {
    res.json({ healthy: true });
}