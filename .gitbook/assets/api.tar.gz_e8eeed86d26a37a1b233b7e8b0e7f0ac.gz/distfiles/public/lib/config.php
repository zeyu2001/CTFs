<?php
$admin = ['id' => "*secret*", 'pw' => "*secret*", 'level' => 1];
