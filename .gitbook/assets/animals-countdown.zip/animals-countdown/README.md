### TetCtf Challenge setup
- How to run: docker-compose up --build
- Access: localhost:3000 