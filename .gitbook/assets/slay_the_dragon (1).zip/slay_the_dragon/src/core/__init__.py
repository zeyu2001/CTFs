from . import config
from .game import Game

__all__ = ["Game", "config"]
