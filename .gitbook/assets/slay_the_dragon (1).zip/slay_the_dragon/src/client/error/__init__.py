from .error import Error

__all__ = [
    "Error",
]
